#pragma once
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <Windows.h>
using namespace std;

class Node {
public:
    int value;  //-1 for S // -2 for F // -3 for obstacle
    int distance; // Distance from start node
    bool car;
    Node* left;
    Node* right;
    Node* bottom;
    Node* top;

    Node(int val) {
    
        car = false;
        value = val;
        distance = 9999;
        left = right = bottom = top = nullptr;
    }
};

struct QueueNode {
    Node* data;
    QueueNode* next;

    QueueNode(Node* val) {
    
        data = val;
        next = nullptr;

    }};
class Queue {
public:
    
    QueueNode* front;
    QueueNode* rear;

    Queue() {
    
        front = rear = nullptr;
    }


    void enqueue(Node* val) {

        QueueNode* newNode = new QueueNode(val);

        if (isEmpty()) {

            front = rear = newNode;

        }
        else {

            rear->next = newNode;

            rear = newNode;
        }
    }

    Node* dequeue() {

        if (!isEmpty()) {

            QueueNode* temp = front;
            Node* val = temp->data;

            front = front->next;

            delete temp;

            return val;
        }
        return nullptr;

    }

    bool isEmpty() {

        return front == nullptr;

    }
};



class StringQueue {

private:
    struct QueueNode {

        string data;

        QueueNode* next;

        QueueNode(string val) {
            data = val;
            next = nullptr;
        
        }

    };
    QueueNode* front;
    QueueNode* rear;
public:
    StringQueue() {
        front = rear = nullptr;
    }
    void enqueue(string val) {

        QueueNode* newNode = new QueueNode(val);

        if (isEmpty()) {

            front = rear = newNode;
        }

        else {
            rear->next = newNode;

            rear = newNode;

        }
    }

    string dequeue() {

        if (!isEmpty()) {
            QueueNode* temp = front;

            string val = temp->data;

            front = front->next;
            delete temp;

            return val;

        }
        return "";
    }

    bool isEmpty() {

        return front == nullptr;
    }


    void clear() {

        while (!isEmpty()) {

            dequeue();
        }
    }
};