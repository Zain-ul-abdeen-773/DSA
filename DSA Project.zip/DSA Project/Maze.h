#pragma once
#include <iostream>
#include "Queue.h"
#include "Stack.h"
#include <cstdlib>
#include <ctime>
#include <Windows.h>
#include <fstream>
#include <sstream>
using namespace std;

class Graph {
public:
    Node*** nodes;// A 2D dynamic array of pointers to Node objects, representing the graph's grid.
    int rows;
    int cols;
    Queue queue;   //for dijkstra
    int Score;

    Graph(int r, int c) : rows(r), cols(c) {
        nodes = new Node * *[rows];// Dynamically allocates memory for a 2D array of Node pointers.
        for (int i = 0; i < rows; ++i) {
            nodes[i] = new Node * [cols];//: Allocates memory for each row
            for (int j = 0; j < cols; ++j) {

                nodes[i][j] = new Node(0);
            }
        }
        setVariables();
        connectNodes();
    }    
/*
Loops through every node in the graph grid.
Randomly determines the number of edges (numEdges) for each node (1 to 4).
switch (direction): Randomly connects a node to one of its neighbors (left, right, top, or bottom).
Ensures edges are bidirectional (e.g., left of A points to B, and right of B points to A).
Prevents invalid connections (e.g., nodes at the grid's edges)
*/

    void connectNodes() {
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                int numEdges = rand() % 4 + 1; // Random number of edges (1 to 4)
                for (int k = 0; k < numEdges; ++k) {
                    int direction = rand() % 4;
                    switch (direction) {
                    case 0: // left
                        if (j > 0 && nodes[i][j]->left == NULL) {
                            nodes[i][j]->left = nodes[i][j - 1];
                            nodes[i][j - 1]->right = nodes[i][j]; // Connect back
                        }
                        break;
                    case 1: // right
                        if (j < cols - 1 && nodes[i][j]->right == NULL) {
                            nodes[i][j]->right = nodes[i][j + 1];
                            nodes[i][j + 1]->left = nodes[i][j]; //Connect back
                        }
                        break;
                    case 2: // top
                        if (i > 0 && nodes[i][j]->top == NULL) {
                            nodes[i][j]->top = nodes[i - 1][j];
                            nodes[i - 1][j]->bottom = nodes[i][j]; // Connect  back
                        }
                        break;
                    case 3: // bottom
                        if (i < rows - 1 && nodes[i][j]->bottom == NULL) {
                            nodes[i][j]->bottom = nodes[i + 1][j];
                            nodes[i + 1][j]->top = nodes[i][j]; //Connect back
                        }
                        break;
                    }
                }
            }
        }
    }

/*
Randomly selects a start node (value = -1) on the leftmost column and marks it as the car's initial position.
Randomly selects a finish node (value = -2) on the rightmost column.Randomly generates obstacles (value = -3) and ensures they don’t overlap with the start/finish nodes.
Stores obstacles in a queue for easy management.
Similarly, power-ups (value = -4) are generated and stored in a queue
*/

    void setVariables() {
        int startRow = rand() % rows;
        int startCol = 0;

        nodes[startRow][startCol]->value = -1;
        nodes[startRow][startCol]->car = true;// Mark as start node

        int finishRow = rand() % rows;
        int finishCol = cols - 1;

        nodes[finishRow][finishCol]->value = -2; // Mark as finish node

        int obstacleRow;
        int obstacleCol;

        int powerRow;
        int powerCol;

        Queue obstaclesQueue;
        Queue powerupsQueue;

        for (int i = 0; i < rows / 2.5; i++) {
            obstacleRow = rand() % rows;
            obstacleCol = (rand() % cols) + 1;
            while (obstacleCol == 0 || obstacleCol == cols || obstacleCol == 1) {
                obstacleRow = rand() % rows;
                obstacleCol = (rand() % cols) + 1;
            }
            nodes[obstacleRow][obstacleCol - 1]->value = -3; // mark as obstacle
            obstaclesQueue.enqueue(nodes[obstacleRow][obstacleCol - 1]);
        }

        // Generate power-ups
        for (int i = 0; i < rows / 2.5; i++) { // cal for how many items
            powerRow = rand() % rows;
            powerCol = (rand() % cols) + 1;
            while (powerCol == 0 || powerCol == cols || powerCol == 1 || nodes[powerRow][powerCol - 1]->value == -3) {
                powerRow = rand() % rows;
                powerCol = (rand() % cols) + 1;
            }
            nodes[powerRow][powerCol - 1]->value = -4; // mark as powerup
            powerupsQueue.enqueue(nodes[powerRow][powerCol - 1]);
        }
        while (!obstaclesQueue.isEmpty()) {
            obstaclesQueue.dequeue();
        }
        while (!powerupsQueue.isEmpty()) {
            powerupsQueue.dequeue();
        }
    }
    /*
    Prints the grid with colors representing different node types 
    (S for start, F for finish, O for obstacles, etc.).
    Uses SetConsoleTextAttribute to change the console's text color.
    */
    void printGraph() {
        HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE); //color
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                if (nodes[i][j]->value == -1)
                {
                    SetConsoleTextAttribute(h, 9);
                    cout << "S";
                }
                else if (nodes[i][j]->car == true && nodes[i][j]->value == -1)
                {
                    SetConsoleTextAttribute(h, 9); //blue colour
                    cout << "S";

                }
                else if (nodes[i][j]->car == true && (nodes[i][j]->value != -1 && nodes[i][j]->value != -2 && nodes[i][j]->value != -3 && nodes[i][j]->value != -4))
                {
                    SetConsoleTextAttribute(h, 6); //yellow color
                    cout << "C";
                }
                else if (nodes[i][j]->car == true && nodes[i][j]->value == -4)
                {
                    SetConsoleTextAttribute(h, 2);  //when car is passing through a poweer up then the color of car changes to green
                    cout << "C";
                }
                else if (nodes[i][j]->car == true && nodes[i][j]->value == -3)
                {
                    SetConsoleTextAttribute(h, 4);  //when car is passing through a obstacle then the color of car changes to red
                    cout << "C";
                }
                else if (nodes[i][j]->car == true && nodes[i][j]->value == -2)
                {
                    SetConsoleTextAttribute(h, 9);  //when car reaches Finish point then the color of car changes to blue
                    cout << "C";
                }
                else if (nodes[i][j]->value == -2)
                {
                    SetConsoleTextAttribute(h, 9); //blue color
                    cout << "F";
                }
                else if (nodes[i][j]->value == -3)
                {
                    SetConsoleTextAttribute(h, 4); //red color
                    cout << "O";
                }
                else if (nodes[i][j]->value == -4)
                {
                    SetConsoleTextAttribute(h, 2); //green color
                    cout << "P";
                }
                else
                {
                    SetConsoleTextAttribute(h, 8);
                    cout << "+";
                }
                if (j < cols - 1 && nodes[i][j]->right != nullptr)
                {
                    SetConsoleTextAttribute(h, 8);
                    cout << "---";
                }
                else
                    cout << "   ";
            }
            cout << "\n";
            if (i < rows - 1) {
                for (int j = 0; j < cols; ++j) {
                    if (nodes[i][j]->bottom != nullptr)
                    {
                        SetConsoleTextAttribute(h, 8);
                        cout << "|";
                    }
                    else
                        cout << " ";
                    for (int k = 0; k < 3; ++k)
                        cout << " ";
                }
                cout << "\n";
            }
        }
    }
    //-----------------------------------------------------------------------------------//
    bool dijkstra() {
        // Find start node
        int startRow, startCol;
        findStartNode(startRow, startCol);
        if (nodes[startRow][startCol] == nullptr){
            return false;}
        nodes[startRow][startCol]->distance = 0;
        queue.enqueue(nodes[startRow][startCol]);
        while (!queue.isEmpty()) {
            Node* current = queue.dequeue();

            // Update distances of adjacent nodes
            updateDistance(current->left, current);

            updateDistance(current->right, current);

            updateDistance(current->top, current);

            updateDistance(current->bottom, current);   //4
        }

        // Find finish node
        int finishRow, finishCol;
        findFinishNode(finishRow, finishCol);
        return nodes[finishRow][finishCol]->distance != 9999;
    }
    void updateDistance(Node* neighbor, Node* current) {
        if (neighbor != nullptr) {
            int newDistance = current->distance + 1; // Assuming each edge has weight 9999
            if (newDistance < neighbor->distance) {
                neighbor->distance = newDistance;
                queue.enqueue(neighbor);
            }
        }
    }
    void findStartNode(int& row, int& col) {
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                if (nodes[i][j]->value == -1) {
                    row = i;
                    col = j;
                    return;
                }
            }
        }
    }
    void findFinishNode(int& row, int& col) {
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                if (nodes[i][j]->value == -2) {
                    row = i;
                    col = j;
                    return;
                }
            }
        }
    }
    void findCarNode(int& row, int& col)
    {
        for (int i = 0; i < rows; ++i) {

            for (int j = 0; j < cols; ++j) {
                if (nodes[i][j]->car == true) {
                    row = i;
                    col = j;
                    return;
                }
            }
        }
    }
    void MoveCar(string Direction)

    {
        int CarRow, CarCol;
        findCarNode(CarRow, CarCol);

        int FinalCarRow, FinalCarCol;
        findFinishNode(FinalCarRow, FinalCarCol);
        if (Direction == "up")
        {
            if (nodes[CarRow][CarCol]->top != NULL)

            {
                nodes[CarRow][CarCol]->top->car = true;
                nodes[CarRow][CarCol]->car = false;
            }
        }
        else  if (Direction == "down")
        {
            if (nodes[CarRow][CarCol]->bottom != NULL)
            {
                nodes[CarRow][CarCol]->bottom->car = true;

                nodes[CarRow][CarCol]->car = false;
            }
        }
        else  if (Direction == "left")
        {
            if (nodes[CarRow][CarCol]->left != NULL)
            {
                nodes[CarRow][CarCol]->left->car = true;

                nodes[CarRow][CarCol]->car = false;

            }
        }
        else  if (Direction == "right")
        {
            if (nodes[CarRow][CarCol]->right != NULL)

            {
                nodes[CarRow][CarCol]->right->car = true;

                nodes[CarRow][CarCol]->car = false;
            }
        }
    }
    StringStack shortestPathStack;
    void findShortestPath() {
        // Run Dijkstra's algorithm
        bool pathExists = dijkstra();
        if (!pathExists) {

            cout << "No path found from start to finish.\n";
            return;
        }
        // Find the finish node
        int finishRow, finishCol;
        findFinishNode(finishRow, finishCol);
        // Reconstruct the path from finish to start
        reconstructPath(finishRow, finishCol);
        
    }
    void reconstructPath(int row, int col) {
        shortestPathStack.clear();
        // Find start node
        int startRow, startCol;
        findStartNode(startRow, startCol);

        // Traverse from finish to start and add directions to the stack
        while (row != startRow || col != startCol) {
            Node* current = nodes[row][col];
            if (current->left != nullptr && current->left->distance == current->distance - 1) {
                shortestPathStack.push("right");
                col--;
            }
            else if (current->right != nullptr && current->right->distance == current->distance - 1) {
                shortestPathStack.push("left");
                col++;
            }
            else if (current->top != nullptr && current->top->distance == current->distance - 1) {
                shortestPathStack.push("down");
                row--;
            }
            else if (current->bottom != nullptr && current->bottom->distance == current->distance - 1) {
                shortestPathStack.push("up");
                row++;
            }
        }
    }
    void printShortestPath() {
        cout << "Shortest Path: ";
        while (!shortestPathStack.isEmpty()) {

            cout << shortestPathStack.pop() << " ";
        }
        cout << "\n";
    }
    void automatedTraversal() {
        findShortestPath();
        // Find start node
        int startRow, startCol;
        findStartNode(startRow, startCol);
        // Find car node
        int carRow, carCol;
        findCarNode(carRow, carCol);

        // Ensure that both start and car nodes are found
        if (startRow == -1 || startCol == -1 || carRow == -1 || carCol == -1) {
            cout << "Error: Start or car node not found.\n";
            return;
        }
        // Set car position to start position
        nodes[carRow][carCol]->car = false;
        nodes[startRow][startCol]->car = true;
        // Traverse through the directions from the stack
        while (!shortestPathStack.isEmpty()) {
            string direction = shortestPathStack.pop();
            // Move the car based on the direction
            if (direction == "up" && carRow > 0 && nodes[carRow - 1][carCol] != nullptr) {
                MoveCar("up");
                carRow--;
            }
            else if (direction == "down" && carRow < rows - 1 && nodes[carRow + 1][carCol] != nullptr) {
                MoveCar("down");
                carRow++;
            }
            else if (direction == "left" && carCol > 0 && nodes[carRow][carCol - 1] != nullptr) {
                MoveCar("left");
                carCol--;
            }
            else if (direction == "right" && carCol < cols - 1 && nodes[carRow][carCol + 1] != nullptr) {
                MoveCar("right");
                carCol++;

            }
            printGraph();
            Sleep(1000);
            system("CLS");
        }
      
    }
    bool isAtFinish() {

        int carRow, carCol, fRow, fCol;

        findCarNode(carRow, carCol);
        findFinishNode(fRow, fCol);
        if (fRow == carRow && fCol == carCol) {

            return true;
        }
        return false;
    }
    bool isAtObstacle() {
        int carRow, carCol;
        findCarNode(carRow, carCol);
        if (nodes[carRow][carCol]->value == -3)
            return true;
        return false;

    }
    bool isAtPowerup() {

        int carRow, carCol;
        findCarNode(carRow, carCol);

        if (nodes[carRow][carCol]->value == -4) {
            return true;
        }
        return false;
    }
    int shortestPathSteps() {
        // Find the finish node
        int finishRow, finishCol;
        findFinishNode(finishRow, finishCol);
        // Return the distance from start to finish

        return nodes[finishRow][finishCol]->distance;
    }





};




