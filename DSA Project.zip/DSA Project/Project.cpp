#include <iostream>
#include "Maze.h"
#include "Queue.h"
#include "Stack.h"
#include "LinkedList.h"

#include <cstdlib>
#include <string>
#include <ctime>
#include <conio.h>
#include <Windows.h>
#include <fstream>
#include <sstream>

#include <chrono>

using namespace std;

#define KEY_UP 72
#define KEY_DOWN 80
#define KEY_LEFT 75
#define KEY_RIGHT 77
#define KEY_X 120

void color(int color)
{
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

void gotoxy(int x, int y)
{
    COORD c;
    c.X = x;
    c.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);
}


int main() {
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(h, 2);
    cout << "----------------------------------------------Welcome to 2D Race Car Game !---------------------------------------------" << endl;
    cout << endl;
    //-----------------------------------------------------Loading Bar Start-----------------------------------------------------------//
    system("COLOR 0e");

    SetConsoleCP(437);
    SetConsoleOutputCP(437);
    int bar1 = 177, bar2 = 219;

    cout << "\n\n\n\t\t\t\t\t\t\tLoading...";
    cout << "\n\n\t\t\t\t\t\t";

    for (int i = 0; i < 25; i++)
        cout << (char)bar1;

    cout << "\r";
    cout << "\t\t\t\t\t\t";
    for (int i = 0; i < 25; i++)
    {
        cout << (char)bar2;
        Sleep(100);
    }

    cout << "\n\n\t\t\t\t\t\t" << (char)1 << "!";
    system("Pause");

    //---------------------------------------------------------------Loading Bar End--------------------------------------------------------//
    system("CLS");
    cout << endl;
    int Set[] = { 7,7,7 };
    int counter = 2;
    char key;

    for (int i = 0;;)
    {
        gotoxy(10, 5);
        color(Set[0]);
        cout << "1. MANUAL MODE " << endl;
        gotoxy(10, 6);
        color(Set[1]);
        cout << "2. AUTOMATIC MODE " << endl;
        key = _getch(); //type H or P

        if (key == 72 && (counter >= 2 && counter <= 3))
        {
            counter--;
        }
        if (key == 80 && (counter >= 1 && counter <= 2))
        {
            counter++;
        }
        if (key == '\r')
        {
            if (counter == 1)
            {
                cout << endl << "------------------------------------------------------Manual Mode-------------------------------------------------" << endl;
                system("CLS");
                cout << "\n\n" << endl;

                SetConsoleTextAttribute(h, 6);//yellow color
                string  playerName;
                cout << "\n\n";
                cout << "                                                    Enter Player Name: ";
                cin>>playerName;
                cout << endl;

                SetConsoleTextAttribute(h, 13);//pink color
                cout << "                                                      Welcome " << playerName << endl;

                cout << "\n\n\n\n";
                SetConsoleTextAttribute(h, 13);
                int gamemode;
                int diff;
                cout << "                                                    Press 1 To Play Game : " << endl;
                cout << "                                                    Press 2 To Exit the Game: "<<endl;
                cin >> gamemode;
                cout << "\n\n";

                EventTracker eventTracker;
                if(gamemode == 2){
                    cout<<"Exiting in Process...."<<endl;
                    cout<<"Exited"<<endl;
                    return 0;
                }

                //-------------------------------------------Time Game Mode-----------------------------------------//
                if (gamemode == 1)
                {
                    //Code for difficulty
                     cout << "                                                    Press 1 for Easy Difficulty: " << endl;
                     cout << "                                                    Press 2 for Medium Difficulty: " << endl;
                     cout << "                                                    Press 3 for Hard Difficulty: " << endl;
                     cout << "                                                     Select Difficulty: ";
                     cin >> diff;
                    cout << endl;

                    if (diff == 1)
                    {
                        //---------------------------------------Easy Mode--------------------------------------------//
                        srand(time(nullptr));

                        Graph finalGraph(5, 5);  // Declare a variable to store the final graph

                        SetConsoleTextAttribute(h, 10);

                        //creating a graph again and again unless there exist a path from S to F
                        while (true) {
                            Graph currentGraph(5, 5);  // Create a new graph in each iteration

                            if (currentGraph.dijkstra() == true) {
                                SetConsoleTextAttribute(h, 10);
                                cout << "\nThere is a path from 'S' to 'F'.\n";
                                finalGraph = currentGraph;  // Update the final graph with the current one
                                break;  // Exit the loop if a path is found
                            }
                            else if (currentGraph.dijkstra() == false) {
                                SetConsoleTextAttribute(h, 10);
                                cout << "\nThere is no path from 'S' to 'F'. Creating a new graph...\n";

                                currentGraph.printGraph();

                            }
                        }
                        cout << endl << endl;
                        finalGraph.printGraph();

                        cout << endl << endl;
                        //---------------------------------Start MANUAL MODE------------------------------//

                        SetConsoleTextAttribute(h, 6);
                        cout << endl;
                        cout << "Controls " << endl;

                        SetConsoleTextAttribute(h, 2);
                        cout << "up arrow  - ";
                        SetConsoleTextAttribute(h, 14);
                        cout << "Accelerate Up " << endl;

                        SetConsoleTextAttribute(h, 2);
                        cout << "down arrow  - ";
                        SetConsoleTextAttribute(h, 14);
                        cout << "Accelerate Down " << endl;

                        SetConsoleTextAttribute(h, 2);
                        cout << "left arrow - ";
                        SetConsoleTextAttribute(h, 14);
                        cout << "Turn Left" << endl;
                        SetConsoleTextAttribute(h, 2);

                        cout << "right arrow - ";
                        SetConsoleTextAttribute(h, 14);
                        cout << "Turn Right" << endl;

                        SetConsoleTextAttribute(h, 2);
                        cout << "X - ";
                        SetConsoleTextAttribute(h, 14);
                        cout << "Exit / Quit" << endl;

                        //code for up down left right button
                        cout << endl;
                        char keys = _getch();
                        int value = key;

                        system("CLS");
                        auto startTime = chrono::high_resolution_clock::now();  // Start time variable
                        int obscount = 0;
                        int powcount = 0;

                        while (value != KEY_X) {

                            switch (_getch()) {

                            case KEY_UP:
                                finalGraph.MoveCar("up");
                                finalGraph.printGraph();
                                break;
                            case KEY_DOWN:
                                finalGraph.MoveCar("down");
                                finalGraph.printGraph();
                                break;
                            case KEY_LEFT:
                                finalGraph.MoveCar("left");
                                finalGraph.printGraph();
                                break;
                            case KEY_RIGHT:
                                finalGraph.MoveCar("right");
                                finalGraph.printGraph();
                                break;
                            }

                            if (finalGraph.isAtFinish()) {
                                cout << endl << "AT FINISH!" << endl;
                                break;
                            }

                            if (finalGraph.isAtObstacle()) {
                                cout << endl << "Obstacle! Time +2 Seconds Penalty" << endl;
                                eventTracker.addEvent("obstacle");
                            }

                            if (finalGraph.isAtPowerup()) {
                                cout << endl << "Powerup! Time -2 seconds!" << endl;

                                eventTracker.addEvent("powerup");
                            }

                            SetConsoleTextAttribute(h, 6);
                            cout << endl;
                            cout << "Controls " << endl;

                            SetConsoleTextAttribute(h, 2);
                            cout << "up arrow  - ";
                            SetConsoleTextAttribute(h, 14);
                            cout << "Accelerate Up " << endl;

                            SetConsoleTextAttribute(h, 2);
                            cout << "down arrow  - ";
                            SetConsoleTextAttribute(h, 14);
                            cout << "Accelerate Down " << endl;

                            SetConsoleTextAttribute(h, 2);
                            cout << "left arrow - ";
                            SetConsoleTextAttribute(h, 14);
                            cout << "Turn Left" << endl;
                            SetConsoleTextAttribute(h, 2);

                            cout << "right arrow - ";
                            SetConsoleTextAttribute(h, 14);
                            cout << "Turn Right" << endl;

                            SetConsoleTextAttribute(h, 2);
                            cout << "X - ";
                            SetConsoleTextAttribute(h, 14);
                            cout << "Exit / Quit" << endl;

                            key = _getch();
                            value = key;
                            system("CLS");
                        }
                        auto endTime = chrono::high_resolution_clock::now();  // Stop time variable

                        chrono::duration<double> duration = endTime - startTime;

                        // Calculate penalties and rewards using EventTracker
                        chrono::duration<double> eventTrackerDuration = eventTracker.calculateDuration();
                        duration += eventTrackerDuration;

                        cout << "Total Time taken: " << duration.count() << " seconds" << endl;

                        ofstream file;
                        string fileName = "time_scores_" + to_string(gamemode) + "_" + to_string(diff) + ".txt";
                        file.open(fileName, ios::app);

                        if (file.is_open()) {
                            file << "Player Name: " << playerName << endl;
                            file << "Time: " << duration.count() << " seconds" << endl;
                            file << "Difficulty: " << "Easy" << endl;

                            file << "---------------------" << endl << endl;
                            file.close();
                        }
                        else {
                            cout << "Error opening file: " << fileName << endl;
                        }
                        system("pause");
                        return 0;
                    }
                    else if (diff == 2)
                    {
                        //---------------------------------------------------Medium difficulty---------------------------------------//
                        srand(time(nullptr));

                        Graph finalGraph(10, 10);  // Declare a variable to store the final graph

                        SetConsoleTextAttribute(h, 10);

                        //creating a graph again and again unless there exist a path from S to F
                        while (true) {
                            Graph currentGraph(10, 10);  // Create a new graph in each iteration

                            if (currentGraph.dijkstra() == true) {
                                SetConsoleTextAttribute(h, 10);
                                cout << "\nThere is a path from 'S' to 'F'.\n";
                                finalGraph = currentGraph;  // Update the final graph with the current one
                                break;  // Exit the loop if a path is found
                            }
                            else if (currentGraph.dijkstra() == false) {
                                SetConsoleTextAttribute(h, 10);
                                cout << "\nThere is no path from 'S' to 'F'. Creating a new graph...\n";

                                currentGraph.printGraph();
                            }
                        }
                        cout << endl << endl;
                        finalGraph.printGraph();
                        cout << endl << endl;
                        //---------------------------------Start MANUAL MODE------------------------------//

                        SetConsoleTextAttribute(h, 6);
                        cout << endl;
                        cout << "Controls " << endl;

                        SetConsoleTextAttribute(h, 2);
                        cout << "up arrow  - ";
                        SetConsoleTextAttribute(h, 14);
                        cout << "Accelerate Up " << endl;

                        SetConsoleTextAttribute(h, 2);
                        cout << "down arrow  - ";
                        SetConsoleTextAttribute(h, 14);
                        cout << "Accelerate Down " << endl;

                        SetConsoleTextAttribute(h, 2);
                        cout << "left arrow - ";
                        SetConsoleTextAttribute(h, 14);
                        cout << "Turn Left" << endl;
                        SetConsoleTextAttribute(h, 2);

                        cout << "right arrow - ";
                        SetConsoleTextAttribute(h, 14);
                        cout << "Turn Right" << endl;

                        SetConsoleTextAttribute(h, 2);
                        cout << "X - ";
                        SetConsoleTextAttribute(h, 14);
                        cout << "Exit / Quit" << endl;

                        //code for up down left right button
                        cout << endl;
                        char keys=' ';
                        keys = _getch();
                        int value = key;

                        system("CLS");
                        auto startTime = chrono::high_resolution_clock::now();  // Start time variable
                        int obscount = 0;
                        int powcount = 0;

                        while (value != KEY_X) {

                            switch (_getch()) {

                            case KEY_UP:
                                finalGraph.MoveCar("up");
                                finalGraph.printGraph();
                                break;
                            case KEY_DOWN:
                                finalGraph.MoveCar("down");
                                finalGraph.printGraph();
                                break;
                            case KEY_LEFT:
                                finalGraph.MoveCar("left");
                                finalGraph.printGraph();
                                break;
                            case KEY_RIGHT:
                                finalGraph.MoveCar("right");
                                finalGraph.printGraph();
                                break;
                            }

                            if (finalGraph.isAtFinish()) {
                                cout << endl << "AT FINISH!" << endl;
                                break;
                            }

                            if (finalGraph.isAtObstacle()) {
                                cout << endl << "Obstacle! Time +2 Seconds Penalty" << endl;
                                eventTracker.addEvent("obstacle");
                            }

                            if (finalGraph.isAtPowerup()) {
                                cout << endl << "Powerup! Time -2 seconds!" << endl;

                                eventTracker.addEvent("powerup");
                            }


                            SetConsoleTextAttribute(h, 6);
                            cout << endl;
                            cout << "Controls " << endl;

                            SetConsoleTextAttribute(h, 2);
                            cout << "up arrow  - ";
                            SetConsoleTextAttribute(h, 14);
                            cout << "Accelerate Up " << endl;

                            SetConsoleTextAttribute(h, 2);
                            cout << "down arrow  - ";
                            SetConsoleTextAttribute(h, 14);
                            cout << "Accelerate Down " << endl;

                            SetConsoleTextAttribute(h, 2);
                            cout << "left arrow - ";
                            SetConsoleTextAttribute(h, 14);
                            cout << "Turn Left" << endl;
                            SetConsoleTextAttribute(h, 2);


                            cout << "right arrow - ";
                            SetConsoleTextAttribute(h, 14);
                            cout << "Turn Right" << endl;

                            SetConsoleTextAttribute(h, 2);
                            cout << "X - ";
                            SetConsoleTextAttribute(h, 14);
                            cout << "Exit / Quit" << endl;

                            key = _getch();
                            value = key;
                            system("CLS");


                        }

                        auto endTime = chrono::high_resolution_clock::now();  // Stop time variable

                        chrono::duration<double> duration = endTime - startTime;

                        // Calculate penalties and rewards using EventTracker
                        chrono::duration<double> eventTrackerDuration = eventTracker.calculateDuration();
                        duration += eventTrackerDuration;

                        cout << "Total Time taken: " << duration.count() << " seconds" << endl;
                        ofstream file;
                        string fileName = "time_scores_" + to_string(gamemode) + "_" + to_string(diff) + ".txt";
                        file.open(fileName, ios::app);

                        if (file.is_open()) {

                            file << "Player Name: " << playerName << endl;
                            file << "Time: " << duration.count() << " seconds" << endl;
                            file << "Difficulty: " << "Medium" << endl;

                            file << "---------------------" << endl << endl;
                            file.close();
                        }
                        else {
                            cout << "Error opening file: " << fileName << endl;
                        }

                        system("pause");
                        return 0;
                    }
                    else if (diff == 3)
                    {
                        //---------------------------------------------------Hard Difficulty-------------------------------------------//
                        srand(time(nullptr));

                        Graph finalGraph(15, 15);  // Declare a variable to store the final graph

                        SetConsoleTextAttribute(h, 10);

                        //creating a graph again and again unless there exist a path from S to F
                        while (true) {
                            Graph currentGraph(15, 15);  // Create a new graph in each iteration

                            if (currentGraph.dijkstra() == true) {
                                SetConsoleTextAttribute(h, 10);
                                cout << "\nThere is a path from 'S' to 'F'.\n";
                                finalGraph = currentGraph;  // Update the final graph with the current one
                                break;  // Exit the loop if a path is found
                            }
                            else if (currentGraph.dijkstra() == false) {
                                SetConsoleTextAttribute(h, 10);
                                cout << "\nThere is no path from 'S' to 'F'. Creating a new graph...\n";

                                currentGraph.printGraph();
                            }
                        }
                        cout << endl << endl;
                        finalGraph.printGraph();
                        cout << endl << endl;
                        //---------------------------------Start MANUAL MODE------------------------------//

                        SetConsoleTextAttribute(h, 6);
                        cout << endl;
                        cout << "Controls " << endl;

                        SetConsoleTextAttribute(h, 2);
                        cout << "up arrow  - ";
                        SetConsoleTextAttribute(h, 14);
                        cout << "Accelerate Up " << endl;

                        SetConsoleTextAttribute(h, 2);
                        cout << "down arrow  - ";
                        SetConsoleTextAttribute(h, 14);
                        cout << "Accelerate Down " << endl;

                        SetConsoleTextAttribute(h, 2);
                        cout << "left arrow - ";
                        SetConsoleTextAttribute(h, 14);
                        cout << "Turn Left" << endl;
                        SetConsoleTextAttribute(h, 2);

                        cout << "right arrow - ";
                        SetConsoleTextAttribute(h, 14);
                        cout << "Turn Right" << endl;

                        SetConsoleTextAttribute(h, 2);
                        cout << "X - ";
                        SetConsoleTextAttribute(h, 14);
                        cout << "Exit / Quit" << endl;
                        //code for up down left right button
                        cout << endl;
                        char keys = _getch();
                        int value = key;

                        system("CLS");
                        auto startTime = chrono::high_resolution_clock::now();  // Start time variable
                        int obscount = 0;
                        int powcount = 0;

                        while (value != KEY_X) {

                            switch (_getch()) {

                            case KEY_UP:
                                finalGraph.MoveCar("up");
                                finalGraph.printGraph();
                                break;
                            case KEY_DOWN:
                                finalGraph.MoveCar("down");
                                finalGraph.printGraph();
                                break;
                            case KEY_LEFT:
                                finalGraph.MoveCar("left");
                                finalGraph.printGraph();
                                break;
                            case KEY_RIGHT:
                                finalGraph.MoveCar("right");
                                finalGraph.printGraph();
                                break;
                            }

                            if (finalGraph.isAtFinish()) {
                                cout << endl << "AT FINISH!" << endl;
                                break;
                            }

                            if (finalGraph.isAtObstacle()) {
                                cout << endl << "Obstacle! Time +2 Seconds Penalty" << endl;
                                eventTracker.addEvent("obstacle");
                            }

                            if (finalGraph.isAtPowerup()) {
                                cout << endl << "Powerup! Time -2 seconds!" << endl;

                                eventTracker.addEvent("powerup");
                            }
                            SetConsoleTextAttribute(h, 6);
                            cout << endl;
                            cout << "Controls " << endl;

                            SetConsoleTextAttribute(h, 2);
                            cout << "up arrow  - ";
                            SetConsoleTextAttribute(h, 14);
                            cout << "Accelerate Up " << endl;

                            SetConsoleTextAttribute(h, 2);
                            cout << "down arrow  - ";
                            SetConsoleTextAttribute(h, 14);
                            cout << "Accelerate Down " << endl;

                            SetConsoleTextAttribute(h, 2);
                            cout << "left arrow - ";
                            SetConsoleTextAttribute(h, 14);
                            cout << "Turn Left" << endl;
                            SetConsoleTextAttribute(h, 2);

                            cout << "right arrow - ";
                            SetConsoleTextAttribute(h, 14);
                            cout << "Turn Right" << endl;

                            SetConsoleTextAttribute(h, 2);
                            cout << "X - ";
                            SetConsoleTextAttribute(h, 14);
                            cout << "Exit / Quit" << endl;

                            key = _getch();
                            value = key;
                            system("CLS");

                        }

                        auto endTime = chrono::high_resolution_clock::now();  // Stop time variable

                        chrono::duration<double> duration = endTime - startTime;

                        // Calculate penalties and rewards using EventTracker
                        chrono::duration<double> eventTrackerDuration = eventTracker.calculateDuration();
                        duration += eventTrackerDuration;

                        cout << "Total Time taken: " << duration.count() << " seconds" << endl;

                        ofstream file;
                        string fileName = "time_scores_" + to_string(gamemode) + "_" + to_string(diff) + ".txt";
                        file.open(fileName, ios::app);

                        if (file.is_open()) {

                            file << "Player Name: " << playerName << endl;
                            file << "Time: " << duration.count() << " seconds" << endl;
                            file << "Difficulty: " << "Hard" << endl;

                            file << "---------------------" << endl << endl;
                            file.close();
                        }
                        else {
                            cout << "Error opening file: " << fileName << endl;
                        }

                        system("pause");
                        return 0;
                    }
                    else{
                        cout<<"Please enter a valid difficulty mode!"<<endl;
                    }
                    eventTracker.freeEventList();
                }
                 //-------------------------------End Manual Mode-------------------------------------//
            }
            else if (counter == 2)
            {
                cout << endl << "------------------------------------------------Automatic Mode------------------------------------------------" << endl;
                //-----------------------------------Automatic Mode--------------------------------------//
                srand(time(nullptr));

                Graph finalGraph(10, 10);  // Declare a variable to store the final graph

                SetConsoleTextAttribute(h, 10);

                //creating a graph again and again unless there exist a path from S to F
                while (true) {
                    Graph currentGraph(10, 10);  // Create a new graph in each iteration
                    if (currentGraph.dijkstra() == true) {
                        SetConsoleTextAttribute(h, 10);
                        cout << "\nThere is a path from 'S' to 'F'.\n";
                        finalGraph = currentGraph;  // Update the final graph with the current one
                        break;  // Exit the loop if a path is found
                    }
                    else if (currentGraph.dijkstra() == false) {
                        SetConsoleTextAttribute(h, 10);
                        cout << "\nThere is no path from 'S' to 'F'. Creating a new graph...\n";
                        currentGraph.printGraph();
                    }
                }
                cout << endl << endl;
                finalGraph.printGraph();
                cout << endl << endl;
                finalGraph.automatedTraversal();
                //----------------------------------End Automatic Mode---------------------------------------//
            }
            else{
                cout<<"please enter a valid game mode"<<endl;      
            }
            

        }
        Set[0] = 7; //default white color
        Set[1] = 7; //default white color
        Set[2] = 7; //default white color

        if (counter == 1)
        {
            Set[0] = 12; //12 is coolor red
        }
        if (counter == 2)
        {
            Set[1] = 12; //12 is coolor red
        }
        if (counter == 3)
        {
            Set[2] = 12; //12 is coolor red
        }

    }
    return 0;
}