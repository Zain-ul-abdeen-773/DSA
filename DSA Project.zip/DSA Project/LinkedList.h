#pragma once
#include <iostream>
#include <chrono>
#include <thread>

using namespace std;

struct EventNode {
    string eventType;  // "powerup" or "obstacle"
    chrono::high_resolution_clock::time_point eventTime;  // Time when the event occurred
    EventNode* next;  // Pointer to the next node in the linked list
};
class EventTracker {
private:
    EventNode* head;
public:
    EventTracker() {
        head = nullptr;
    }

    void addEvent(string eventType) {
        EventNode* newNode = new EventNode;

        newNode->eventType = eventType;
        newNode->eventTime = chrono::high_resolution_clock::now();
        newNode->next = head;

        head = newNode;         //latest in front
    }

    chrono::duration<double> calculateDuration() {
        chrono::duration<double> duration = chrono::duration<double>::zero();

        int obscount = 0;
        int powcount = 0;



        EventNode* currentEvent = head;

        while (currentEvent != nullptr) {
            if (currentEvent->eventType == "obstacle") {

                obscount++;
            }

            if (currentEvent->eventType == "powerup") {
                powcount++;

            }
            currentEvent = currentEvent->next;

        }


        duration = duration + chrono::seconds(obscount * 2);

        duration = duration - chrono::seconds(powcount * 2);

        return duration;
    }

    void freeEventList() {
        EventNode* currentEvent = head;

        while (currentEvent != nullptr) {

            EventNode* nextEvent = currentEvent->next;


            delete currentEvent;

            currentEvent = nextEvent;

        }
    }
};