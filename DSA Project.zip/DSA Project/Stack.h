#pragma once

#include <iostream>
#include <string>
struct StackNode {

    string data;
    StackNode* next;

    StackNode(const string& val)  {
        data = val;
        next = nullptr;
    }
};
class StringStack {
public:
    StackNode* top;
    StringStack() {
    
        top = nullptr;
    }

    void push(const string& val) {

        StackNode* newNode = new StackNode(val);

        newNode->next = top;
        top = newNode;
    }

    string pop() {
        if (!isEmpty()) {
            string val = top->data;
            top = top->next;
            return val;
        }
        return ""; //  stack is empty

    }

    bool isEmpty()  {

        return top == nullptr;

    }

    void clear() {

        while (!isEmpty()) {
            pop();

        }
    }


};



